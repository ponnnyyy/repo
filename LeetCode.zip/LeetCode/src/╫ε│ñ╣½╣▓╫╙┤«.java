public class 最长公共子串 {
    public  int f()
}
